from django import forms
from .models import company, supplier, role, category, product, staff, user #for the db tables to make view forms
from django.contrib.auth.forms import UserCreationForm #for changing  the user registration form

class LoginForm(forms.Form):
    username = forms.CharField(
        widget= forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )

class UserForm(UserCreationForm):
    username = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password1 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    password2 = forms.CharField(
        widget=forms.PasswordInput(
            attrs={
                "class": "form-control"
            }
        )
    )
    email = forms.CharField(
        widget=forms.TextInput(
            attrs={
                "class": "form-control"
            }
        )
    )

    class Meta:
        model = user
        fields = ('username', 'email', 'password1', 'password2', 'Role')
        labels = {
            'username':'Username',
            'email':'Email',
            'password1':'Password',
            'password2':'Confirm Password',
        }


class CompanyForm(forms.ModelForm):

    class Meta:
        model = company
        fields = ('CompanyName','Address','City','Phone')
        labels = {
            'CompanyName':'Company Name'
        }

        # def __init__(self, *args, **kwargs):
        #     super(CompanyForm,self).__init__(*args, **kwargs)
        #     self.fields['CompanyName'].required = True

class SupplierForm(forms.ModelForm):

    class Meta:
        model = supplier
        fields = ('SupplierName','Address','City','Phone')
        labels = {
            'SupplierName':'Supplier Name'
        }

class RoleForm(forms.ModelForm):

    class Meta:
        model = role
        fields = ('RoleCode','RoleName')
        labels = {
            'RoleCode':'Role Code',
            'RoleName':'Role Name'
        }

class CategoryForm(forms.ModelForm):

    class Meta:
        model = category
        fields = ('CategoryId','CategoryName')
        labels = {
            'CategoryId':'Category Id',
            'CategoryName':'Category Name'
        }

class ProductForm(forms.ModelForm):

    class Meta:
        model = product
        fields = ('ProductCode','ProductName','Category','UnitPrice','SupplierId')
        labels = {
            'ProductCode':'Product Code',
            'ProductName':'Product Name',
            'UnitPrice':'Unit Price',
            'SupplierId':'Supplier Name'
        }

class StaffForm(forms.ModelForm):
    Email = forms.EmailField()

    class Meta:
        model = staff
        fields = ('EmpId','Name','Role','ContactNo','Email','CompanyId')
        labels = {
            'EmpId':'Emp Id',
            'ContactNo':'Contact No',
            'CompanyId':'Company Name',
        }
        def clean_Email(self, *args, **kwargs):
            Email_passed = self.cleaned_data.get("Email")
            if not Email.endswith(".com"):
                raise forms.ValidationError("Not a valid Email")
            return Email_passed
