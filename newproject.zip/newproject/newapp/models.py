from django.db import models
from django.contrib.auth.models import AbstractUser
import datetime
import os

# Create your models here.
class category(models.Model):
    CategoryId = models.CharField(max_length=20, primary_key=True, blank=False,null=False)
    CategoryName = models.CharField(max_length=50, blank=False,null=False)

    def __str__(self):
        return self.CategoryName

class company(models.Model):
    CompanyId = models.IntegerField
    CompanyName = models.CharField(max_length=50, blank=False,null=False)
    Address = models.CharField(max_length=50, blank=False,null=False)
    City = models.CharField(max_length=50, blank=False,null=False)
    Phone = models.IntegerField(blank=False,null=False)

    def __str__(self):
        return self.CompanyName

class role(models.Model):
    RoleCode = models.CharField(max_length=20, primary_key=True, blank=False,null=False)
    RoleName = models.CharField(max_length=50, blank=False,null=False)

    def __str__(self):
        return self.RoleName

class supplier(models.Model):
    SupplierId = models.IntegerField
    SupplierName = models.CharField(max_length=50, blank=False,null=False)
    Address = models.CharField(max_length=50, blank=False,null=False)
    City = models.CharField(max_length=50, blank=False,null=False)
    Phone = models.IntegerField(blank=False,null=False)

    def __str__(self):
        return self.SupplierName

class staff(models.Model):
    EmpId = models.CharField(max_length=20, primary_key=True, blank=False,null=False)
    Name = models.CharField(max_length=50)
    Role = models.ForeignKey(role, on_delete=models.CASCADE, default=1)
    ContactNo = models.IntegerField(blank=False,null=False)
    Email = models.CharField(max_length=50)
    CompanyId = models.ForeignKey(company, on_delete=models.CASCADE, default=1)

class user(AbstractUser):
    Role = models.ForeignKey(role, on_delete=models.CASCADE, default=1)

class product(models.Model):
    ProductCode = models.CharField(max_length=10, primary_key=True, blank=False,null=False)
    ProductName = models.CharField(max_length=50, blank=False,null=False)
    Category = models.ForeignKey(category, on_delete=models.CASCADE, default=1)
    UnitPrice = models.DecimalField(max_digits=5, decimal_places=2, blank=False,null=False)
    SupplierId = models.ForeignKey(supplier, on_delete=models.CASCADE, default=1)

class bill(models.Model):
    BillNo = models.CharField(max_length=10, primary_key=True, blank=False,null=False)
    DateTime = models.DateTimeField(auto_now=True, auto_now_add=False)
    Quantity = models.CharField(max_length=10, blank=False,null=False)
    TotalPrice = models.DecimalField(max_digits=5, decimal_places=2, blank=False,null=False)

class ordered_products(models.Model):
    Bill = models.ForeignKey(bill, on_delete=models.CASCADE, default=1)
    Product = models.ForeignKey(product, on_delete=models.CASCADE, default=1)
    Quantity = models.IntegerField(blank=False,null=False)

    class Meta:
        unique_together = ('Bill', 'Product',)